function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6F7fnmoo3Yt":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

